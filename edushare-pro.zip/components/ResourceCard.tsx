import React, { useState } from 'react';
import { Resource, ResourceType } from '../types';
import { generateResourceSummary } from '../services/geminiService';
import { Button } from './Button';

interface ResourceCardProps {
  resource: Resource;
  isTeacher: boolean;
  onDelete: (id: string) => void;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({ resource, isTeacher, onDelete }) => {
  const [aiSummary, setAiSummary] = useState<string | undefined>(resource.aiSummary);
  const [loadingAi, setLoadingAi] = useState(false);

  const handleGenerateSummary = async () => {
    setLoadingAi(true);
    const summary = await generateResourceSummary(resource);
    setAiSummary(summary);
    setLoadingAi(false);
  };

  const getIcon = () => {
    switch (resource.type) {
      case ResourceType.PDF: return '📄';
      case ResourceType.IMAGE: return '🖼️';
      case ResourceType.LINK: return '🔗';
      case ResourceType.TEXT: return '📝';
      default: return '📁';
    }
  };

  const renderContentPreview = () => {
    if (resource.type === ResourceType.IMAGE) {
      return (
        <div className="h-40 w-full bg-gray-100 rounded-md overflow-hidden mb-3 border border-gray-200">
           <img src={resource.content} alt={resource.title} className="w-full h-full object-cover" />
        </div>
      );
    }
    return null;
  };

  const handleOpen = () => {
    if (resource.type === ResourceType.LINK) {
      window.open(resource.content, '_blank');
    } else if (resource.type === ResourceType.PDF || resource.type === ResourceType.IMAGE) {
      // For Base64 PDF/Image, opening in new tab
      const win = window.open();
      if (win) {
          if (resource.type === ResourceType.PDF) {
               win.document.write(`<iframe src="${resource.content}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
          } else {
               win.document.write(`<img src="${resource.content}" style="max-width:100%"/>`);
          }
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200 border border-gray-200 p-5 flex flex-col h-full relative group">
      {isTeacher && (
        <button 
          onClick={() => onDelete(resource.id)}
          className="absolute top-2 right-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
          title="Delete Resource"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
        </button>
      )}

      <div className="flex items-center gap-2 mb-3">
        <span className="text-2xl" role="img" aria-label={resource.type}>{getIcon()}</span>
        <span className="text-xs font-semibold uppercase tracking-wider text-gray-500">{resource.type}</span>
      </div>
      
      <h3 className="text-lg font-bold text-gray-900 mb-1 leading-tight">{resource.title}</h3>
      <p className="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow">{resource.description}</p>
      
      {renderContentPreview()}

      {aiSummary && (
        <div className="bg-indigo-50 p-3 rounded-lg mb-4 text-xs text-indigo-800 border border-indigo-100">
          <strong className="block mb-1 flex items-center gap-1">
             ✨ AI Summary
          </strong>
          {aiSummary}
        </div>
      )}

      <div className="mt-auto flex gap-2 flex-wrap">
        <Button variant="secondary" onClick={handleOpen} className="flex-1 text-sm">
          {resource.type === ResourceType.LINK ? 'Visit Link' : 'View File'}
        </Button>
        
        {!aiSummary && (
            <Button 
                variant="ghost" 
                onClick={handleGenerateSummary} 
                isLoading={loadingAi}
                className="text-xs px-2"
                title="Generate AI Summary"
            >
                ✨ AI
            </Button>
        )}
      </div>
    </div>
  );
};