import React, { useState, useEffect, useRef } from 'react';
import { Resource, ResourceType, UserRole } from './types';
import { ResourceCard } from './components/ResourceCard';
import { Button } from './components/Button';
import { generateQuizQuestion } from './services/geminiService';

const TEACHER_PASS = "123654";

const App: React.FC = () => {
  // State
  const [role, setRole] = useState<UserRole>('STUDENT');
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [loginError, setLoginError] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | ResourceType>('all');
  
  // Upload State
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDesc, setUploadDesc] = useState("");
  const [uploadType, setUploadType] = useState<ResourceType>(ResourceType.LINK);
  const [uploadContent, setUploadContent] = useState(""); // For Link or Text
  const [uploadFile, setUploadFile] = useState<string | null>(null); // Base64
  
  // Quiz AI State
  const [quizQuestion, setQuizQuestion] = useState<string | null>(null);
  const [generatingQuiz, setGeneratingQuiz] = useState(false);

  // Load resources from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('eduProps_resources');
    if (saved) {
      try {
        setResources(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse resources");
      }
    }
  }, []);

  // Save resources to local storage
  useEffect(() => {
    localStorage.setItem('eduProps_resources', JSON.stringify(resources));
  }, [resources]);

  // Handlers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === TEACHER_PASS) {
      setRole('TEACHER');
      setIsLoginModalOpen(false);
      setPasswordInput("");
      setLoginError(false);
    } else {
      setLoginError(true);
    }
  };

  const handleLogout = () => {
    setRole('STUDENT');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadFile(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddResource = (e: React.FormEvent) => {
    e.preventDefault();
    
    let finalContent = uploadContent;
    if (uploadType === ResourceType.PDF || uploadType === ResourceType.IMAGE) {
      if (!uploadFile) {
        alert("Please select a file.");
        return;
      }
      finalContent = uploadFile;
    }

    const newResource: Resource = {
      id: crypto.randomUUID(),
      type: uploadType,
      title: uploadTitle,
      description: uploadDesc,
      content: finalContent,
      createdAt: Date.now()
    };

    setResources([newResource, ...resources]);
    
    // Reset Form
    setUploadTitle("");
    setUploadDesc("");
    setUploadContent("");
    setUploadFile(null);
    setUploadType(ResourceType.LINK);
  };

  const handleDeleteResource = (id: string) => {
    if (window.confirm("Are you sure you want to delete this resource?")) {
      setResources(resources.filter(r => r.id !== id));
    }
  };

  const handleGenerateQuiz = async () => {
    setGeneratingQuiz(true);
    const q = await generateQuizQuestion(resources);
    setQuizQuestion(q);
    setGeneratingQuiz(false);
  }

  const filteredResources = activeTab === 'all' 
    ? resources 
    : resources.filter(r => r.type === activeTab);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm backdrop-blur-md bg-opacity-90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-lg">E</div>
              <span className="font-bold text-xl tracking-tight text-slate-800">EduShare Pro</span>
            </div>
            <div className="flex items-center gap-4">
              {role === 'TEACHER' ? (
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                    Teacher Mode
                  </span>
                  <Button variant="secondary" onClick={handleLogout} className="text-sm">Exit Teacher Mode</Button>
                </div>
              ) : (
                <Button variant="primary" onClick={() => setIsLoginModalOpen(true)} className="text-sm">
                  Teacher Login
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header Section */}
        <div className="mb-10 text-center">
          <h1 className="text-4xl font-extrabold text-slate-900 mb-4">
            {role === 'TEACHER' ? 'Classroom Management' : 'Classroom Resources'}
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            {role === 'TEACHER' 
              ? 'Upload and manage course materials, helpful links, and diagrams for your students.' 
              : 'Access all the materials uploaded by your teacher. Use AI tools to summarize or quiz yourself.'}
          </p>
        </div>

        {/* Teacher Upload Section */}
        {role === 'TEACHER' && (
          <div className="mb-12 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-200">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span>📤</span> Upload New Material
              </h2>
            </div>
            <div className="p-6">
              <form onSubmit={handleAddResource} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                    <input 
                      required 
                      type="text" 
                      value={uploadTitle}
                      onChange={(e) => setUploadTitle(e.target.value)}
                      placeholder="e.g., Chapter 1 Summary" 
                      className="w-full rounded-lg border-slate-300 shadow-sm border p-2 focus:ring-primary focus:border-primary" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                    <textarea 
                      required
                      value={uploadDesc}
                      onChange={(e) => setUploadDesc(e.target.value)}
                      placeholder="Briefly explain what this resource is..." 
                      className="w-full rounded-lg border-slate-300 shadow-sm border p-2 focus:ring-primary focus:border-primary h-24 resize-none" 
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Resource Type</label>
                    <div className="grid grid-cols-4 gap-2">
                      {[ResourceType.LINK, ResourceType.IMAGE, ResourceType.PDF, ResourceType.TEXT].map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setUploadType(t)}
                          className={`px-3 py-2 text-xs font-bold rounded-md border ${uploadType === t ? 'bg-primary text-white border-primary' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    {uploadType === ResourceType.LINK && (
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">URL</label>
                        <input type="url" required value={uploadContent} onChange={e => setUploadContent(e.target.value)} className="w-full rounded-lg border-slate-300 border p-2" placeholder="https://..." />
                      </div>
                    )}
                    {uploadType === ResourceType.TEXT && (
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Content</label>
                        <textarea required value={uploadContent} onChange={e => setUploadContent(e.target.value)} className="w-full rounded-lg border-slate-300 border p-2" placeholder="Type text content here..." />
                      </div>
                    )}
                    {(uploadType === ResourceType.PDF || uploadType === ResourceType.IMAGE) && (
                      <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">File Upload</label>
                         <input type="file" accept={uploadType === ResourceType.PDF ? "application/pdf" : "image/*"} onChange={handleFileChange} className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-indigo-700"/>
                         <p className="text-xs text-slate-400 mt-1">Note: Browser storage is limited. Please upload small files for this demo.</p>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 flex justify-end">
                    <Button type="submit">Add Resource</Button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Filters and AI Tools */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
          <div className="flex p-1 bg-white rounded-lg border border-slate-200 shadow-sm">
            {['all', ResourceType.LINK, ResourceType.PDF, ResourceType.IMAGE, ResourceType.TEXT].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === tab ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {tab === 'all' ? 'All' : tab}
              </button>
            ))}
          </div>
          
          {role === 'STUDENT' && (
             <Button variant="ghost" className="text-indigo-600 bg-indigo-50 hover:bg-indigo-100" onClick={handleGenerateQuiz} isLoading={generatingQuiz}>
                ⚡ Generate Quiz from Resources
             </Button>
          )}
        </div>

        {/* AI Quiz Section Display */}
        {quizQuestion && (
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-xl shadow-lg mb-8 relative">
                <button onClick={() => setQuizQuestion(null)} className="absolute top-4 right-4 text-white opacity-70 hover:opacity-100">✕</button>
                <h3 className="font-bold text-lg mb-2 flex items-center gap-2">🤖 AI Pop Quiz</h3>
                <div className="whitespace-pre-wrap font-medium">{quizQuestion}</div>
            </div>
        )}

        {/* Resource Grid */}
        {filteredResources.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-xl border border-dashed border-slate-300">
            <div className="text-5xl mb-4">📭</div>
            <h3 className="text-lg font-medium text-slate-900">No resources found</h3>
            <p className="text-slate-500">{role === 'TEACHER' ? 'Start by uploading a file or link above.' : 'Check back later for updates from your teacher.'}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.map((res) => (
              <ResourceCard 
                key={res.id} 
                resource={res} 
                isTeacher={role === 'TEACHER'} 
                onDelete={handleDeleteResource}
              />
            ))}
          </div>
        )}
      </main>

      {/* Login Modal */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 transform transition-all scale-100">
            <div className="text-center mb-6">
              <div className="mx-auto w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white mb-4">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
              </div>
              <h2 className="text-2xl font-bold text-slate-900">Teacher Access</h2>
              <p className="text-slate-500">Please enter your passcode to manage content.</p>
            </div>
            
            <form onSubmit={handleLogin}>
              <div className="mb-6">
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all text-center text-lg tracking-widest"
                  placeholder="••••••"
                  autoFocus
                />
                {loginError && (
                  <p className="text-red-500 text-sm mt-2 text-center">Incorrect password. Please try again.</p>
                )}
              </div>
              
              <div className="flex gap-3">
                <Button type="button" variant="secondary" className="flex-1" onClick={() => { setIsLoginModalOpen(false); setLoginError(false); setPasswordInput(""); }}>
                  Cancel
                </Button>
                <Button type="submit" className="flex-1">
                  Login
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;