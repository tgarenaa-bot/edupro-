import { GoogleGenAI } from "@google/genai";
import { Resource, ResourceType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-3-flash-preview';

export const generateResourceSummary = async (resource: Resource): Promise<string> => {
  try {
    let prompt = `You are a helpful teaching assistant. Please provide a concise, engaging summary (max 50 words) for the following educational resource.\n\nTitle: ${resource.title}\nDescription: ${resource.description}\n`;

    if (resource.type === ResourceType.TEXT) {
      prompt += `Content: ${resource.content}`;
    } else if (resource.type === ResourceType.LINK) {
      prompt += `Link Context: This is an external resource at ${resource.content}`;
    }

    // Note: For real image analysis, we would pass the base64 data to inlineData.
    // Here we focus on text metadata for speed and simplicity in this demo context,
    // unless it's a small text based request.

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });

    return response.text || "No summary available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Could not generate AI summary at this time.";
  }
};

export const generateQuizQuestion = async (resources: Resource[]): Promise<string> => {
    if (resources.length === 0) return "No resources available to generate a quiz.";

    const context = resources.map(r => `- ${r.title}: ${r.description}`).join('\n');
    
    try {
        const response = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: `Based on the following list of class resources, generate one multiple-choice question to test the student's understanding. Format it clearly.\n\nResources:\n${context}`
        });
        return response.text || "Could not generate quiz.";
    } catch (error) {
        return "AI is taking a break.";
    }
}
