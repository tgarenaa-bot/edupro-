export enum ResourceType {
  LINK = 'LINK',
  IMAGE = 'IMAGE',
  PDF = 'PDF',
  TEXT = 'TEXT'
}

export interface Resource {
  id: string;
  type: ResourceType;
  title: string;
  description: string;
  content: string; // URL or Base64 or Text content
  createdAt: number;
  aiSummary?: string;
}

export type UserRole = 'STUDENT' | 'TEACHER';